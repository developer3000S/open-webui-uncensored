import logging

import chromadb
from chromadb import Settings
from chromadb.utils.batch_utils import create_batches
from open_webui.config import (
    CHROMA_CLIENT_AUTH_CREDENTIALS,
    CHROMA_CLIENT_AUTH_PROVIDER,
    CHROMA_DATA_PATH,
    CHROMA_DATABASE,
    CHROMA_HTTP_HEADERS,
    CHROMA_HTTP_HOST,
    CHROMA_HTTP_PORT,
    CHROMA_HTTP_SSL,
    CHROMA_TENANT,
)
from open_webui.retrieval.vector.main import (
    GetResult,
    SearchResult,
    VectorDBBase,
    VectorItem,
)
from open_webui.retrieval.vector.utils import process_metadata

log = logging.getLogger(__name__)


class ChromaClient(VectorDBBase):
    def __init__(self):
        settings_dict = {
            'allow_reset': True,
            'anonymized_telemetry': False,
        }
        if CHROMA_CLIENT_AUTH_PROVIDER is not None:
            settings_dict['chroma_client_auth_provider'] = CHROMA_CLIENT_AUTH_PROVIDER
        if CHROMA_CLIENT_AUTH_CREDENTIALS is not None:
            settings_dict['chroma_client_auth_credentials'] = CHROMA_CLIENT_AUTH_CREDENTIALS

        if CHROMA_HTTP_HOST != '':
            self.client = chromadb.HttpClient(
                host=CHROMA_HTTP_HOST,
                port=CHROMA_HTTP_PORT,
                headers=CHROMA_HTTP_HEADERS,
                ssl=CHROMA_HTTP_SSL,
                tenant=CHROMA_TENANT,
                database=CHROMA_DATABASE,
                settings=Settings(**settings_dict),
            )
        else:
            self.client = chromadb.PersistentClient(
                path=CHROMA_DATA_PATH,
                settings=Settings(**settings_dict),
                tenant=CHROMA_TENANT,
                database=CHROMA_DATABASE,
            )

    def has_collection(self, collection_name: str) -> bool:
        # Check if the collection exists based on the collection name.
        # chromadb's list_collections() returns Collection objects (1.x), so a
        # bare `name in collections` membership test is always False — compare
        # against the names. (hasattr guard tolerates versions that yield names.)
        collections = self.client.list_collections()
        collection_names = [c.name if hasattr(c, 'name') else c for c in collections]
        return collection_name in collection_names

    def delete_collection(self, collection_name: str):
        # Delete the collection based on the collection name.
        return self.client.delete_collection(name=collection_name)

    def search(
        self,
        collection_name: str,
        vectors: list[list[float | int]],
        filter: dict | None = None,
        limit: int = 10,
    ) -> SearchResult | None:
        # Search for the nearest neighbor items based on the vectors and return 'limit' number of results.
        try:
            collection = self.client.get_collection(name=collection_name)
            if collection:
                result = collection.query(
                    query_embeddings=vectors,
                    n_results=limit,
                    where=filter,
                )

                # chromadb has cosine distance, 2 (worst) -> 0 (best). Re-odering to 0 -> 1
                # https://docs.trychroma.com/docs/collections/configure cosine equation
                distances: list = result['distances'][0]
                distances = [2 - dist for dist in distances]
                distances = [[dist / 2 for dist in distances]]

                return SearchResult(
                    **{
                        'ids': result['ids'],
                        'distances': distances,
                        'documents': result['documents'],
                        'metadatas': result['metadatas'],
                    }
                )
            return None
        except Exception:
            return None

    def query(self, collection_name: str, filter: dict, limit: int | None = None) -> GetResult | None:
        # Query the items from the collection based on the filter.
        try:
            collection = self.client.get_collection(name=collection_name)
            if collection:
                result = collection.get(
                    where=filter,
                    limit=limit,
                )

                return GetResult(
                    **{
                        'ids': [result['ids']],
                        'documents': [result['documents']],
                        'metadatas': [result['metadatas']],
                    }
                )
            return None
        except Exception:
            return None

    def get(self, collection_name: str) -> GetResult | None:
        # Get all the items in the collection.
        collection = self.client.get_collection(name=collection_name)
        if collection:
            result = collection.get()
            return GetResult(
                **{
                    'ids': [result['ids']],
                    'documents': [result['documents']],
                    'metadatas': [result['metadatas']],
                }
            )
        return None

    def get_with_embeddings(
        self,
        collection_name: str,
        filter: dict | None = None,
    ) -> list[VectorItem] | None:
        # Vectors are readable from Chroma but are not part of GetResult, so they are
        # returned as VectorItem directly: the only caller wants to hand them straight
        # back to insert() without recomputing them.
        try:
            collection = self.client.get_collection(name=collection_name)
        except Exception:
            return None
        if not collection:
            return None

        result = collection.get(where=filter, include=['embeddings', 'metadatas', 'documents'])
        embeddings = result.get('embeddings')
        if embeddings is None:
            return None

        ids = result.get('ids') or []
        documents = result.get('documents') or [None] * len(ids)
        metadatas = result.get('metadatas') or [None] * len(ids)

        items = []
        for idx, chunk_id in enumerate(ids):
            vector = embeddings[idx]
            # numpy arrays arrive from chroma; a plain list is what insert() expects.
            vector = vector.tolist() if hasattr(vector, 'tolist') else list(vector)
            items.append(
                VectorItem(
                    id=str(chunk_id),
                    text=documents[idx] or '',
                    vector=vector,
                    metadata=metadatas[idx] or {},
                )
            )
        return items

    def insert(self, collection_name: str, items: list[VectorItem]):
        # Insert the items into the collection, if the collection does not exist, it will be created.
        collection = self.client.get_or_create_collection(name=collection_name, metadata={'hnsw:space': 'cosine'})

        ids = [item['id'] for item in items]
        documents = [item['text'] for item in items]
        embeddings = [item['vector'] for item in items]
        metadatas = [process_metadata(item['metadata']) for item in items]

        for batch in create_batches(
            api=self.client,
            documents=documents,
            embeddings=embeddings,
            ids=ids,
            metadatas=metadatas,
        ):
            collection.add(*batch)

    def upsert(self, collection_name: str, items: list[VectorItem]):
        # Update the items in the collection, if the items are not present, insert them. If the collection does not exist, it will be created.
        collection = self.client.get_or_create_collection(name=collection_name, metadata={'hnsw:space': 'cosine'})

        ids = [item['id'] for item in items]
        documents = [item['text'] for item in items]
        embeddings = [item['vector'] for item in items]
        metadatas = [process_metadata(item['metadata']) for item in items]

        collection.upsert(ids=ids, documents=documents, embeddings=embeddings, metadatas=metadatas)

    def delete(
        self,
        collection_name: str,
        ids: list[str] | None = None,
        filter: dict | None = None,
    ):
        # Delete the items from the collection based on the ids.
        try:
            collection = self.client.get_collection(name=collection_name)
            if collection:
                if ids:
                    collection.delete(ids=ids)
                elif filter:
                    collection.delete(where=filter)
        except Exception:
            # If collection doesn't exist, that's fine - nothing to delete
            log.debug(f'Attempted to delete from non-existent collection {collection_name}. Ignoring.')
            pass

    def reset(self):
        # Resets the database. This will delete all collections and item entries.
        return self.client.reset()
